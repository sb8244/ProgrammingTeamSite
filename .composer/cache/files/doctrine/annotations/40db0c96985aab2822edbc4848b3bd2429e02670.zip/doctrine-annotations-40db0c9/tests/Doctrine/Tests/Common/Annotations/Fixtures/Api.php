<?php

/**
 * This class is not an annotation
 * It's a class build to test ClassWithInclude
 */
class Api
{
	
}