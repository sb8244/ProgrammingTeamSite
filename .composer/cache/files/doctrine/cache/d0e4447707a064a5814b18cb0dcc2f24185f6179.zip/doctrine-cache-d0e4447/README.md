# Doctrine Cache

Cache component extracted from the Doctrine Common project.

## Changelog

### v1.2

* Added support for MongoDB as Cache Provider
* Fix namespace version reset
