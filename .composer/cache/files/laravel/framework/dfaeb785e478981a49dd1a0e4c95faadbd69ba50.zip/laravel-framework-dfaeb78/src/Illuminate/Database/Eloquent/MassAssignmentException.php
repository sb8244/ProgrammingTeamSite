<?php namespace Illuminate\Database\Eloquent;

class MassAssignmentException extends \RuntimeException {}