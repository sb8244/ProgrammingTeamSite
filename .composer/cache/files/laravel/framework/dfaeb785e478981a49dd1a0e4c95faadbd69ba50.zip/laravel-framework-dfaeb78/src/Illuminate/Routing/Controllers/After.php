<?php namespace Illuminate\Routing\Controllers;

class After extends Filter {}